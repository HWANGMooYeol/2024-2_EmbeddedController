/*----------------------------------------------------------------\
@ Embedded Controller by Young-Keun Kim - Handong Global University
Author           : Moon Hyeonho
Created          : 05-03-2021
Modified         : 10-14-2023
Language/ver     : C++ in Keil uVision

Description      : Distributed to Students for LAB_EXTI
/----------------------------------------------------------------*/

#ifndef __EC_EXTI_H
#define __EC_EXTI_H

#include "stm32f411xe.h"

#define FALL 0
#define RISE 1
#define BOTH 2

#ifdef __cplusplus
 extern "C" {
#endif /* __cplusplus */

void EXTI_init(GPIO_TypeDef *Port, int pin, int trig, int priority); 
//Creating an interrupt by specifying the pin, trigger type, and priority level
void EXTI_enable(uint32_t pin);          // mask in IMR
void EXTI_disable(uint32_t pin);        // unmask in IMR
uint32_t is_pending_EXTI(uint32_t pin); //pending interval when the configured pin triggers
void clear_pending_EXTI(uint32_t pin);  //Clear by setting pending to 1 when the given interrupt is completed

#ifdef __cplusplus
}
#endif /* __cplusplus */
	 
#endif