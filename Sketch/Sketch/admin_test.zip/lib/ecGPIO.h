/*----------------------------------------------------------------\
@ Embedded Controller by Young-Keun Kim - Handong Global University
Author           : Moon Hyeonho
Created          : 05-03-2021
Modified         : 10-14-2023
Language/ver     : C++ in Keil uVision

Description      : Distributed to Students for LAB_GPIO
/----------------------------------------------------------------*/

#ifndef __ECGPIO_H
#define __ECGPIO_H

#include "stm32f411xe.h"
#include "ecRCC.h"

#define INPUT  0x00
#define OUTPUT 0x01
#define EC_AF     0x02
#define EC_ANALOG 0x03

#define HIGH 1
#define LOW  0

#define LED_PIN 	5
#define BUTTON_PIN 13

#define EC_NONE 0
#define EC_PU 1
#define EC_PD 2

#define EC_PUSH_PULL 0
#define EC_PUSH_DRAIN 1

#define EC_LOW 0
#define EC_MEDIUM 1
#define EC_FAST 2
#define EC_HIGH 3

#define p_n    //Number of pins  


#ifdef __cplusplus
 extern "C" {
#endif /* __cplusplus */


void GPIO_init(GPIO_TypeDef *Port, int pin, unsigned int mode);
void GPIO_write(GPIO_TypeDef *Port, int pin, unsigned int Output);
unsigned int GPIO_read(GPIO_TypeDef *Port, int pin);
void GPIO_mode(GPIO_TypeDef *Port, int pin, unsigned int mode);
void GPIO_ospeed(GPIO_TypeDef* Port, int pin, unsigned int speed);
void GPIO_otype(GPIO_TypeDef* Port, int pin, unsigned int type);
void GPIO_pupd(GPIO_TypeDef* Port, int pin, unsigned int pupd);
void LED_toggle(void);

//pin


typedef struct { //Structure for Combining Ports and Pins
    GPIO_TypeDef *Port;
    int pin;
} Pin_t;

extern Pin_t;



void PIN_init(Pin_t pin, unsigned int mode);
void PIN_write(Pin_t pin, unsigned int Output);
unsigned int PIN_read(Pin_t pin);
void PIN_mode(Pin_t pin, unsigned int mode);
void PIN_ospeed(Pin_t pin, unsigned int speed);
void PIN_otype(Pin_t pin, unsigned int type);
void PIN_pupd(Pin_t pin, unsigned int pupd);



void sevensegment_init(void); 
void sevensegment_decoder(uint8_t  num);
void min_sevensegment_decoder(uint8_t  num);
void min_sevensegment_decoder_P(void);
void mid_sevensegment_init (void); 

void sevensegment_display_init(void); 
void sevensegment_display(uint8_t  num);


 
#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif
