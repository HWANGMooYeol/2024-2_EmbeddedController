/*----------------------------------------------------------------\
@ Embedded Controller by Young-Keun Kim - Handong Global University
Author           : Moon Hyeonho
Created          : 05-03-2021
Modified         : 10-14-2023
Language/ver     : C++ in Keil uVision

Description      : Distributed to Students for LAB_GPIO
/----------------------------------------------------------------*/



#include "stm32f4xx.h"
#include "ecGPIO.h"

void GPIO_init(GPIO_TypeDef *Port, int pin, unsigned int mode){ 
	
	
	// mode  : Input(0), Output(1), AlterFunc(2), Analog(3)   
	if (Port == GPIOA)
		RCC_GPIOA_enable();
	if (Port == GPIOB)
		RCC_GPIOB_enable();
	if (Port == GPIOC)
		RCC_GPIOC_enable();
	if (Port == GPIOD)
		RCC_GPIOD_enable();
	if (Port == GPIOE)
		RCC_GPIOE_enable();
	//if (Port == GPIOF)
	//	RCC_GPIOF_enable();
	//if (Port == GPIOG)
	//	RCC_GPIOG_enable();
	if (Port == GPIOH)
		RCC_GPIOH_enable();

	// You can also make a more general function of
	// void RCC_GPIO_enable(GPIO_TypeDef *Port); 

	GPIO_mode(Port, pin, mode);
	
}


// GPIO Mode          : Input(00), Output(01), AlterFunc(10), Analog(11)
void GPIO_mode(GPIO_TypeDef *Port, int pin, unsigned int mode){
	
   Port->MODER &= ~(3UL<<(pin*2));     
   Port->MODER |= (mode <<(pin*2));    
}


// GPIO Speed          : Low speed (00), Medium speed (01), Fast speed (10), High speed (11)
void GPIO_ospeed(GPIO_TypeDef *Port, int pin, unsigned int speed){
	Port->OSPEEDR &= ~(3UL<<( pin *2));
  Port->OSPEEDR |= speed<<( pin *2);		
}

// GPIO Output Type: Output push-pull (0, reset), Output open drain (1)
void GPIO_otype(GPIO_TypeDef *Port, int pin, unsigned int type){
	 Port->OTYPER &= ~(1UL << pin) ;
   Port->OTYPER |= (type << pin) ;
}

// GPIO Push-Pull    : No pull-up, pull-down (00), Pull-up (01), Pull-down (10), Reserved (11)
void GPIO_pupd(GPIO_TypeDef *Port, int pin, unsigned int pupd){
   	Port->PUPDR &= ~(3UL<<( pin *2));   
		Port->PUPDR |= pupd<<( pin *2);
}

// GPIO output data
void GPIO_write(GPIO_TypeDef *Port, int pin, unsigned int Output){
		Port->ODR &= ~(1UL<< pin );   
		Port->ODR |= (Output << pin );
}

void LED_toggle(void){
	GPIOA->ODR ^= GPIO_ODR_ODR_5;
}
// GPIO Read 
unsigned int GPIO_read(GPIO_TypeDef *Port, int pin){
	
	unsigned int bitVal = (Port->IDR>>pin) & 1UL; 
	
	return bitVal;    
}


//     pin    //

void PIN_init(Pin_t pin, unsigned int mode){
	GPIO_init(pin.Port, pin.pin, mode);
}

void PIN_write(Pin_t pin, unsigned int Output){
	GPIO_write(pin.Port, pin.pin, Output);
}

unsigned int PIN_read(Pin_t pin){
	GPIO_read(pin.Port, pin.pin);
}

void PIN_mode(Pin_t pin, unsigned int mode){
	GPIO_mode(pin.Port, pin.pin, mode);
}

void PIN_ospeed(Pin_t pin, unsigned int speed){
	GPIO_ospeed(pin.Port, pin.pin, speed);
}

void PIN_otype(Pin_t pin, unsigned int type){
	GPIO_otype(pin.Port, pin.pin, type);
}

void PIN_pupd(Pin_t pin, unsigned int pupd){
	GPIO_pupd(pin.Port, pin.pin, pupd);
}

void sevensegment_init(void){
	
	Pin_t pin[8] = { //each segment
		{GPIOA, 5},  //a
		{GPIOA, 6},  //b
		{GPIOA, 7},  //c        
		{GPIOB, 6},  //d
		{GPIOC, 7},  //e        
		{GPIOA, 9},  //f        
		{GPIOA, 8},  //g       
		{GPIOB, 10}  //dp       
    };
	
	for(int i=0; i<8;i++){
		
		PIN_init(pin[i], OUTPUT);          //  calls RCC_GPIO(A, B, C)_enable()
		PIN_pupd(pin[i], EC_NONE);         //  GPIOX LED_PIN5 Push-Pull  No pull-up, pull-down (00)
		PIN_otype(pin[i], 0);              //  GPIOX LED_PIN5 Output Type: Output push-pull (0, reset)
		PIN_ospeed(pin[i], EC_MEDIUM);     // GPIOX Speed LED_PIN5 Medium speed(01)
	}
		
}

void mid_sevensegment_init(void){
	
	Pin_t pin[8] = { //each segment
		{GPIOB, 9},  //a
		{GPIOA, 6},  //b
		{GPIOA, 7},  //c        
		{GPIOB, 6},  //d
		{GPIOC, 7},  //e        
		{GPIOA, 9},  //f        
		{GPIOA, 8},  //g        
		{GPIOB, 10}  //dp      
    };
	
	for(int i=0; i<8;i++){
		
		PIN_init(pin[i], OUTPUT);          //  calls RCC_GPIO(A, B, C)_enable()
		PIN_pupd(pin[i], EC_NONE);         //  GPIOX LED_PIN5 Push-Pull  No pull-up, pull-down (00)
		PIN_otype(pin[i], 0);              //  GPIOX LED_PIN5 Output Type: Output push-pull (0, reset)
		PIN_ospeed(pin[i], EC_MEDIUM);     // GPIOX Speed LED_PIN5 Medium speed(01)
	}
		
}

void sevensegment_decoder(uint8_t  cnt){
	
	Pin_t pin[8] = { //each segment
		{GPIOB, 5},  //a
		{GPIOA, 6},  //b
		{GPIOA, 7},  //c        
		{GPIOB, 6},  //d
		{GPIOC, 7},  //e        
		{GPIOA, 9},  //f        
		{GPIOA, 8},  //g        
		{GPIOB, 10}  //dp        

    };

	
    unsigned int number_2[10][8] = {  //7-segment display ouput
			{0, 0, 0, 0, 0, 0, 1, 1}, // zero
			{1, 0, 0, 1, 1, 1, 1, 1}, // one
			{0, 0, 1, 0, 0, 1, 0, 1}, // two
			{0, 0, 0, 0, 1, 1, 0, 1}, // three
			{1, 0, 0, 1, 1, 0, 0, 1}, // four
			{0, 1, 0, 0, 1, 0, 0, 1}, // five
			{0, 1, 0, 0, 0, 0, 0, 1}, // six
			{0, 0, 0, 1, 1, 0, 1, 1}, // seven
			{0, 0, 0, 0, 0, 0, 0, 1}, // eight
			{0, 0, 0, 0, 1, 0, 0, 1}  // nine
	};
		

    for (int i = 0; i < 8; i++) {  // P.2 print 7-segment display ouput
        PIN_write(pin[i], number_2[cnt][i]);
    }		
}

void min_sevensegment_decoder(uint8_t  cnt){
	
	Pin_t pin[8] = { //each segment
		{GPIOB, 9},  //a
		{GPIOA, 6},  //b
		{GPIOA, 7},  //c        
		{GPIOB, 6},  //d
		{GPIOC, 7},  //e        
		{GPIOA, 9},  //f        
		{GPIOA, 8},  //g        
		{GPIOB, 10}  //dp        

    };

	
    unsigned int number_2[3][8] = {  //7-segment display ouput
			{0, 0, 0, 0, 0, 0, 1, 1}, // zero
			{1, 1, 1, 0, 0, 0, 1, 1}, // one
			{1, 0, 0, 1, 0, 0, 0, 1}, // two
	};
		

    for (int i = 0; i < 8; i++) {  // P.2 print 7-segment display ouput
        PIN_write(pin[i], number_2[cnt][i]);
    }		
}

void min_sevensegment_decoder_P(void){
	
	Pin_t pin[8] = { //each segment
		{GPIOB, 9},  //a
		{GPIOA, 6},  //b
		{GPIOA, 7},  //c        
		{GPIOB, 6},  //d
		{GPIOC, 7},  //e        
		{GPIOA, 9},  //f        
		{GPIOA, 8},  //g       
		{GPIOB, 10}  //dp       
    };

	
    unsigned int number_2[1][8] = {  //7-segment display ouput
			{0, 0, 1, 1, 0, 0, 0, 0}, // P
	};
		

    for (int i = 0; i < 8; i++) {  // P.2 print 7-segment display ouput
        PIN_write(pin[i], number_2[0][i]);
    }		
}

void sevensegment_display_init(void){
	
	Pin_t de_pin[4] = {  //each segment
				{GPIOA, 7},  //a
				{GPIOB, 6},  //b
				{GPIOC, 7},  //c        
				{GPIOA, 9},  //d
    };
	
		for(int i=0; i<4;i++){
		PIN_init(de_pin[i], OUTPUT);          //  calls RCC_GPIO(A, B, C)_enable()
		PIN_pupd(de_pin[i], EC_NONE);         //  GPIOX LED_PIN5 Push-Pull  No pull-up, pull-down (00)
		PIN_otype(de_pin[i], 0);              //  GPIOX LED_PIN5 Output Type: Output push-pull (0, reset)
		PIN_ospeed(de_pin[i], EC_MEDIUM);     // GPIOX Speed LED_PIN5 Medium speed(01)
	}
		
}
				
void sevensegment_display(uint8_t  num){
		
	Pin_t de_pin[4] = {  //each segment
			{GPIOA, 7},  //a
			{GPIOB, 6},  //b
			{GPIOC, 7},  //c        
			{GPIOA, 9},  //d
   };
		
	for (int i = 0; i < 4; i++) {
		PIN_write(de_pin[i], (num >> i) & 1);  //Reading the Current Number by Bit Shifting
	}

}










