/**
******************************************************************************
* @author	Moon Hyron ho
* @Mod		2023. 10. 2
* @brief	Embedded Controller:  LAB Digital In/Out
*					 - Toggle LED LD2 by Button B1 pressing
* 
******************************************************************************
*/

#include "stm32f411xe.h"
#include "math.h"

// #include "ecSTM32F411.h"
#include "ecPinNames.h"
#include "ecGPIO.h"
#include "ecSysTick.h"
#include "ecRCC.h"
#include "ecEXTI.h"
#include "ecTIM.h"
#include "ecPWM.h"   


// Definition Button Pin & PWM Port, Pin
#define BUTTON_PIN 13
#define Direction_PIN PC_2
#define PWM_PIN PA_0

uint32_t cnt = 0;
uint32_t state = 0;
uint8_t VEL = 0;
static int toggle = 0;
uint8_t CW=0;


void setup(void);
void TIM3_IRQHandler(void);
void EXTI15_10_IRQHandler(void);


int main(void) {
	// Initialization --------------------------------------------------
	setup();	
	sevensegment_display_init();//seven segment
	
	// Infinite Loop ---------------------------------------------------
	while(1){
		if(VEL==1){
					state = !state;
					GPIO_write(GPIOA, 5, !state);
					delay_ms(1000);
					
				}else if(VEL==2){
					state = !state;
					GPIO_write(GPIOA, 5, !state);
					delay_ms(500);
					
				}else{
					GPIO_write(GPIOA, 5, 0);
				}
	}
}


void TIM3_IRQHandler(void){
	if(is_UIF(TIM3)){			// Check UIF(update interrupt flag)
			cnt++;
		
		GPIO_write(GPIOC, 2, CW);
		
			if (cnt > 500) {//500msec interrupt
				
				if(CW==0){
					if(VEL==0){
						PWM_duty(PWM_PIN, (float)(0));    //0
					
					}else if(VEL==1){
						PWM_duty(PWM_PIN, (float)(1*0.5));	//50%
					
					}else if(VEL==2){
						PWM_duty(PWM_PIN, (float)(1));     //High
					}
					
				}else{
					if(VEL==0){
						PWM_duty(PWM_PIN, (float)(1));    //0
					
					}else if(VEL==1){
						PWM_duty(PWM_PIN, (float)(1*0.5));	//50%
					
					}else if(VEL==2){
						PWM_duty(PWM_PIN, (float)(0));     //High
					}
				}

				
				sevensegment_display(VEL);
				
				cnt = 0;
			}
		}
		clear_UIF(TIM3); 		// Clear UI flag by writing 0
}

void EXTI15_10_IRQHandler(void) {
	if (is_pending_EXTI(BUTTON_PIN)) { // pendig 1
		
		VEL++;
			if(VEL==3){
					VEL=0;
					CW = !CW;
			}

		
		clear_pending_EXTI(BUTTON_PIN); // pending clear
	}
}


// Initialiization 
void setup(void) {	
	RCC_HSI_init();
	RCC_PLL_init();
	SysTick_init();
	
	
	//Bueeon EXTI
	EXTI_init(GPIOC, BUTTON_PIN, RISE, 0);   //// Executing interrupts for BUTTON_PIN  Rise
	GPIO_init(GPIOC, BUTTON_PIN, INPUT);          //  calls RCC_GPIO( C)_enable()
	GPIO_pupd(GPIOC, BUTTON_PIN, EC_PD);         //    pull-down
	
	//State Led
	GPIO_init(GPIOA, 5, OUTPUT);          //  calls RCC_GPIO(A, B, C)_enable()
	GPIO_otype(GPIOA, 5, 0);              //  GPIOX LED_PIN5 Output Type: Output push-pull (0, reset)
	GPIO_ospeed(GPIOA, 5, EC_MEDIUM);     // GPIOX Speed LED_PIN5 Medium speed(01)
	
	// PWM of 1 msec:  TIM2_CH1 (PA_0 AFmode)
	PWM_init(PWM_PIN);	
	GPIO_otype(GPIOA, 0, EC_PUSH_PULL);     //PWM Pin Push-Pull
	GPIO_pupd(GPIOA, 0, EC_PU);             //PWM Pin Pull-up
	GPIO_ospeed(GPIOA, 0, EC_FAST);         //PWM Pin Fast 
	PWM_period(PWM_PIN, 1);   // 1 msec PWM period  
	
	//Moter Direction Pin
	PWM_init(Direction_PIN);	
	GPIO_init(GPIOC, 2, OUTPUT);          //  calls RCC_GPIO( C)_enable()
	
	TIM_UI_init(TIM3, 1);			// TIM2 Update-Event Interrupt every 1 msec 
	TIM_UI_enable(TIM3);
	
	
}
